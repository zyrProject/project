 $(document).ready(function(){

 $('#load_staffData').click(function(){//读取员工名单cvs文件
  $.ajax({
   url:"员工名单.csv",
   dataType:"text",
   success:function(data)
   {
    var employee_data = data.split(/\r?\n|\r/);
	var table_data='<h3 class="text-primary">员工名单</h3>';
   table_data += '<table class="table table-bordered table-striped">';
    for(var count = 0; count<employee_data.length; count++)
    {
     var cell_data = employee_data[count].split(",");
     table_data += '<tr>';
     for(var cell_count=0; cell_count<cell_data.length; cell_count++)
     {
      if(count === 0)
      {
       table_data += '<th>'+cell_data[cell_count]+'</th>';
      }
      else
      {
       table_data += '<td>'+cell_data[cell_count]+'</td>';
      }
     }
     table_data += '</tr>';
    }
    table_data += '</table>';
    $('#employee_table').html(table_data);
   }
  });
 });
 
 $('#load_FiveOneData').click(function(){//读取五险一金名单
  $.ajax({
   url:"五险费率.csv",
   dataType:"text",
   success:function(data)
   {
    var employee_data = data.split(/\r?\n|\r/);
	var table_data='<h3 class="text-primary">五险一金</h3>';
     table_data += '<table class="table table-bordered table-striped">';
    for(var count = 0; count<employee_data.length; count++)
    {
     var cell_data = employee_data[count].split(",");
     table_data += '<tr>';
     for(var cell_count=0; cell_count<cell_data.length; cell_count++)
     {
      if(count === 0)
      {
       table_data += '<th>'+cell_data[cell_count]+'</th>';
      }
      else
      {
       table_data += '<td>'+cell_data[cell_count]+'</td>';
      }
     }
     table_data += '</tr>';
    }
    table_data += '</table>';
    $('#fiveOne_table').html(table_data);
   }
  });
 });
 
 $('#load_averageData').click(function(){//读取本市职工月平均工资
  $.ajax({
   url:"本市职工月平均工资.csv",
   dataType:"text",
   success:function(data)
   {
    var employee_data = data.split(/\r?\n|\r/);
	var table_data='<h3 class="text-primary">本市职工月平均工资</h3>';
    table_data+= '<table class="table table-bordered table-striped">';
    for(var count = 0; count<employee_data.length; count++)
    {
     var cell_data = employee_data[count].split(",");
     table_data += '<tr>';
     for(var cell_count=0; cell_count<cell_data.length; cell_count++)
     {
      if(count === 0)
      {
       table_data += '<th>'+cell_data[cell_count]+'</th>';
      }
      else
      {
       table_data += '<td>'+cell_data[cell_count]+'</td>';
      }
     }
     table_data += '</tr>';
    }
    table_data += '</table>';
    $('#average_table').html(table_data);
   }
  });
 });
 
   $('#load_taxData').click(function(){//读取tax名单
  $.ajax({
   url:"个税税率.csv",
   dataType:"text",
   success:function(data)
   {
    var employee_data = data.split(/\r?\n|\r/);
	var table_data='<h3 class="text-primary">个税税率</h3>';
     table_data += '<table class="table table-bordered table-striped">';
    for(var count = 0; count<employee_data.length; count++)
    {
     var cell_data = employee_data[count].split(",");
     table_data += '<tr>';
     for(var cell_count=0; cell_count<cell_data.length; cell_count++)
     {
      if(count === 0)
      {
       table_data += '<th>'+cell_data[cell_count]+'</th>';
      }
      else
      {
       table_data += '<td>'+cell_data[cell_count]+'</td>';
      }
     }
     table_data += '</tr>';
    }
    table_data += '</table>';
    $('#Tax_table').html(table_data);
   }
  });
 });
 
  $('#load_kpiData').click(function(){//读取kpi文件
  $.ajax({
   url:"绩效工资标准.csv",
   dataType:"text",
   success:function(data)
   {
    var employee_data = data.split(/\r?\n|\r/);
	var table_data='<h3 class="text-primary">绩效工资标准</h3>';
    table_data += '<table class="table table-bordered table-striped">';
    for(var count = 0; count<employee_data.length; count++)
    {
     var cell_data = employee_data[count].split(",");
     table_data += '<tr>';
     for(var cell_count=0; cell_count<cell_data.length; cell_count++)
     {
      if(count === 0)
      {
       table_data += '<th>'+cell_data[cell_count]+'</th>';
      }
      else
      {
       table_data += '<td>'+cell_data[cell_count]+'</td>';
      }
     }
     table_data += '</tr>';
    }
    table_data += '</table>';
    $('#Kpi_table').html(table_data);
   }
  });
 });
 
 
   $('#output_fiveOneData').click(function(){//输出工资表一（五险一金详情）
    var table_data='<h3 class="text-success">五险一金详情</h3>';
    table_data += '<table class="table table-bordered table-striped">';
	var rowNumber = $("#employee_table").find("tr").length;//获取员工名单总行数
	var colNumber = $("#fiveOne_table").find("th").length;//获得五险一金表的总列数
	var average =  $("#average_table tr:eq(1) td:eq(0)").text();
	var max =  average*3;
	var min =  average*0.6;

	   	for(var employeeRcount=1; employeeRcount<$("#employee_table").find("tr").length; employeeRcount++)//for 循环员工表单
	       {
	        table_data += '<tr>';
	        table_data+='<th></th>';
	     	var name= $("#employee_table tr:eq("+employeeRcount+") td:eq(0)").text();
		    var salary=$("#employee_table tr:eq("+employeeRcount+") td:eq(1)").text(); 
			table_data+='<th>';
			table_data+=name;
            table_data+='</th>';
            table_data+='<th>'+'单位'+'</th>';
            table_data+='</tr>';
			var personSum=0;
			var orgSum=0;
			var houseRate= $("#employee_table tr:eq("+employeeRcount+") td:eq(3)").text(); 
			var insuranceResult=insurance(table_data,colNumber,max,min,salary,personSum,orgSum);//将每人五险费率一对一计算出来
			table_data=insuranceResult[0];
			personSum=insuranceResult[1];
			orgSum=insuranceResult[2];
            var  housetax=salary*houseRate;
            var	 maxh= max*houseRate;
            var  minh= min*houseRate;		
            var houseFeeResult=houseFee(table_data,salary,max,min,personSum,orgSum,maxh,minh,housetax);			
		    table_data=houseFeeResult[0];
			personSum=houseFeeResult[1];
			orgSum=houseFeeResult[2];
	        table_data += '<tr>';
            table_data+='<td>'+'总计'+'</td>';
			table_data+='<td>'+personSum.toFixed(2)+'</td>';
	        table_data+='<td>'+orgSum.toFixed(2)+'</td>';
	        table_data+='</tr>';
	           }
	 table_data += '</table>';
     $("#fiveOneResult_table").html(table_data);
	 
 });
 
   
   $('#output_salary').click(function(){//输出工资条2（收入详情）
       var totalRow= $("#employee_table").find("tr").length;
	   var table_data='<h3 class="text-success">收入详情</h3>';
	   table_data+= '<table class="table table-bordered table-striped">';
	   table_data+='<tr>';//输出表头
       table_data+='<th>姓名</th>';
	   table_data+='<th>岗位工资</th>';
	   table_data+='<th>绩效工资</th>';
	   table_data+='<th>五险一金（个人）</th>';
	   table_data+='<th>五险一金（单位）</th>';
	   table_data+='<th>税前收入</th>';
	   table_data+='<th>扣税</th>';
	   table_data+='<th>税后收入</th>';
	   table_data+='</tr>';
	   table_data = calculateIncome(table_data,totalRow);
	   table_data += '</table>';
     $("#Sum_table").html(table_data);
 });
 
 
   $('#buttonCalculate').click(function(){//手写工资等信息
       var name = $("#name").val();
	   var salary=$("#salary").val();
	   var kpi = $("#kpi").val();
	   var house = $("#house").val();
       var table_data='<h3 class="text-success">计算结果</h3>'; 	  
	   var table_data = '<table class="table table-bordered table-striped">';
	      	table_data += '<tr>';
		 	table_data+= '<th></th>';
			table_data+='<th>'+name+'</th>';
			table_data+='<th>单位</th>';
			var colNumber = $("#fiveOne_table").find("th").length;//获得五险一金列数
	        var average =  $("#average_table tr:eq(1) td:eq(0)").text();
	        var max =  average*3;
	        var min =  average*0.6;
			var personSum=0;
			var orgSum=0;
			var houseTax= salary*house;
			var	 maxh= max*house;
            var  minh= min*house;		
			var insuranceResult=insurance(table_data,colNumber,max,min,salary,personSum,orgSum);	
		    table_data=insuranceResult[0];
			personSum=parseFloat(insuranceResult[1]);
			orgSum=parseFloat(insuranceResult[2]);
		    var houseResult = houseFee(table_data,salary,max,min,personSum,orgSum,maxh,minh,houseTax);
            table_data=houseResult[0];
            personSum=houseResult[1];
            orgSum=	houseResult[2];
            table_data += '<tr>';
			var personSumRound = personSum.toFixed(2);
			var orgSumRound = orgSum.toFixed(2);
            table_data+='<td>'+'总计'+'</td>';
			table_data+='<td>'+personSumRound+'</td>';
	        table_data+='<td>'+orgSumRound+'</td>';
	        table_data+='</tr>';	
			table_data+='<tr>';
	   table_data+='<th>岗位工资</th>';
	   table_data+='<th>绩效工资</th>';
	   table_data+='<th>五险一金（个人）</th>';
	   table_data+='<th>五险一金（单位）</th>';
	   table_data+='<th>税前收入</th>';
	   table_data+='<th>扣税</th>';
	   table_data+='<th>税后收入</th>';
	   table_data+='</tr>';
	   table_data+='<td>'+salary+'</td>';
		  var kpiA='A';
		  var kpiB='B';
		  var kpiC='C';
		  var kpiD='D';
		 if(kpi==kpiA){
		   var bonus= $("#Kpi_table tr:eq(1) td:eq(0)").text();
		
		  }else if(kpi==kpiB){
		  	 var bonus= $("#Kpi_table tr:eq(1) td:eq(1)").text();
		
		  }else if(kpi==kpiC){
		  var bonus= $("#Kpi_table tr:eq(1) td:eq(2)").text();
		  
		  }else {
		  	var bonus= $("#Kpi_table tr:eq(1) td:eq(3)").text();
		  }
		   table_data+='<td>'+bonus+'</td>';
		   table_data+='<td>'+personSumRound+'</td>';
		   table_data+='<td>'+orgSumRound+'</td>';
	       var beforeTax = parseFloat(salary)+parseFloat(bonus)-parseFloat(personSumRound);
		   table_data+='<td>'+beforeTax.toFixed(2)+'</td>';
		   var tax=findTax(beforeTax);
		   table_data+='<td>'+tax+'</td>';
		   var afterTax = parseFloat(beforeTax)-parseFloat(tax);
		   table_data+='<td>'+afterTax.toFixed(2)+'</td>';
           table_data += '</table>';
           $("#input_table").html(table_data);

 });

  function findTax(beforeTax){//计算应缴纳税额
          var tax = 0;
		  var taxAmount=beforeTax-3500;
		  if(taxAmount<=0){
		    return tax;
		  }
		  var colTotal=$("#Tax_table").find("th").length;
		 /* alert(colTotal);*/
		  var prevlevel=0;
          for(var colNum=1;colNum<colTotal;colNum++){
		    var taxLevel= $("#Tax_table tr:eq(0) th:eq("+colNum+")").text();
			var taxRate= $("#Tax_table tr:eq(1) td:eq("+(colNum-1)+")").text();
		    if(taxAmount<=taxLevel){
			       tax=tax+(taxAmount-prevlevel)*parseFloat(taxRate);
				   break;
			}
			tax=tax+(parseFloat(taxLevel)-prevlevel)*taxRate;
            prevlevel=parseFloat(taxLevel);	
            if(colNum==colTotal-1){
			taxRate= $("#Tax_table tr:eq(1) td:eq("+(colNum)+")").text();
			tax = tax+(taxAmount-taxLevel)*parseFloat(taxRate);
			break;
			}			
          }	
           tax = tax.toFixed(2);		  
		   return tax;
    }
  function findKpi(rowNum){//根据绩效工资标准表计算员工应得绩效工资
          var kpi = $("#employee_table tr:eq("+rowNum+") td:eq(2)").text();
		  var kpiA='A';
		  var kpiB='B';
		  var kpiC='C';
		  var kpiD='D';
		 if(kpi==kpiA){
		   var bonus= $("#Kpi_table tr:eq(1) td:eq(0)").text();
		
		  }else if(kpi==kpiB){
		  	 var bonus= $("#Kpi_table tr:eq(1) td:eq(1)").text();
		
		  }else if(kpi==kpiC){
		  var bonus= $("#Kpi_table tr:eq(1) td:eq(2)").text();
		  
		  }else {
		  	var bonus= $("#Kpi_table tr:eq(1) td:eq(3)").text();
		
		  }
       return bonus;
  }
  
   function houseFee(table_data,salary,max,min,personSum,orgSum,maxHouse,minHouse,pnoSalary){//计算出住房公积金数额
          	if(salary>=max){
			var house =$("#employee_table tr:eq(0) th:eq(3)").text();
			table_data += '<tr>';
	        
	        table_data+='<td>'+'住房'+'</td>';
            
			table_data+='<td>'+maxHouse.toFixed(2)+'</td>';
	        table_data+='<td>'+maxHouse.toFixed(2)+'</td>';
	        table_data+='</tr>';
			personSum=personSum+maxHouse;
			orgSum=orgSum+maxHouse;
			}
			else if(salary<=min){
			var house =$("#employee_table tr:eq(0) th:eq(3)").text();
			table_data += '<tr>';
	        
	        table_data+='<td>'+'住房'+'</td>';
			table_data+='<td>'+minHouse.toFixed(2)+'</td>';
	        table_data+='<td>'+minHouse.toFixed(2)+'</td>';
	        table_data+='</tr>';
			personSum=personSum+minHouse;
			orgSum=orgSum+minHouse;
			}
			else{
			var house =$("#employee_table tr:eq(0) th:eq(3)").text();
			table_data += '<tr>';
	        
	        table_data+='<td>'+'住房'+'</td>';
			table_data+='<td>'+pnoSalary.toFixed(2)+'</td>';
	        table_data+='<td>'+pnoSalary.toFixed(2)+'</td>';
	        table_data+='</tr>';
			personSum=personSum+pnoSalary;
			orgSum=orgSum+pnoSalary;
			}
			return [table_data, personSum,orgSum];
			
  }

  function insurance(table_data,colNumber,max,min,salary,personSum,orgSum){//遍历保险表单
     for(var fiveOneColumn=1;fiveOneColumn<colNumber; fiveOneColumn++){         
	       /* table_data += '<tr>';
            table_data += '<td>test</td>';	
			table_data +='</tr>'; */     
			if(salary>=max){
			table_data += '<tr>';
			var type = $("#fiveOne_table tr:eq(0) th:eq("+fiveOneColumn+")").text();
			
			table_data+='<td>';
			table_data+=type
			table_data+='</td>';
			var personTaxRate = $("#fiveOne_table tr:eq(2) td:eq("+fiveOneColumn+")").text();
			var personSalary = max*personTaxRate;
			table_data+='<td>';
			table_data+=personSalary.toFixed(2);
			table_data+='</td>';
			var orgaTaxRate=  $("#fiveOne_table tr:eq(1) td:eq("+fiveOneColumn+")").text();
			var orgaSalary=max*orgaTaxRate;
			table_data+='<td>'+orgaSalary.toFixed(2)+'</td>';	 
			table_data+='</tr>';
			personSum=personSum+personSalary;
			orgSum=orgSum+orgaSalary;
			}
            else if(salary<=min){
			
	
			table_data += '<tr>';
			var type = $("#fiveOne_table tr:eq(0) th:eq("+fiveOneColumn+")").text();
			
			table_data+='<td>';
			table_data+=type
			table_data+='</td>';
			var personTaxRate = $("#fiveOne_table tr:eq(2) td:eq("+fiveOneColumn+")").text();
			var personSalary = min*personTaxRate;
			table_data+='<td>';
			table_data+=personSalary.toFixed(2);
			table_data+='</td>';
			var orgaTaxRate=  $("#fiveOne_table tr:eq(1) td:eq("+fiveOneColumn+")").text();
			var orgaSalary=min*orgaTaxRate;
			table_data+='<td>'+orgaSalary.toFixed(2)+'</td>';	 
			table_data+='</tr>';
			personSum=personSum+personSalary;
			orgSum=orgSum+orgaSalary;
			}
			
			else{
			table_data += '<tr>';
			var type = $("#fiveOne_table tr:eq(0) th:eq("+fiveOneColumn+")").text();
			
			table_data+='<td>';
			table_data+=type
			table_data+='</td>';
			var personTaxRate = $("#fiveOne_table tr:eq(2) td:eq("+fiveOneColumn+")").text();
			var personSalary = salary*personTaxRate;
			table_data+='<td>';
			table_data+=personSalary.toFixed(2);
			table_data+='</td>';
			var orgaTaxRate=  $("#fiveOne_table tr:eq(1) td:eq("+fiveOneColumn+")").text();
			var orgaSalary=salary*orgaTaxRate;
			table_data+='<td>'+orgaSalary.toFixed(2)+'</td>';	 
			table_data+='</tr>';
			personSum=personSum+personSalary;
			orgSum=orgSum+orgaSalary;
			}	
			
			}
			return [table_data, personSum,orgSum];
  }
  
   function calculateIncome(table_data,totalRow){//计算出工资条2所需数据
         for(var rowNum=1;rowNum<totalRow;rowNum++){
	      table_data+='<tr>';
		  var name=$("#employee_table tr:eq("+rowNum+") td:eq(0)").text();
		  var basicSalary=$("#employee_table tr:eq("+rowNum+") td:eq(1)").text();//输出员工岗位薪水
		  table_data+='<td>'+name+'</td>';
		  table_data+='<td>'+basicSalary+'</td>';
		  var bonus=findKpi(rowNum);
		  table_data+='<td>'+bonus+'</td>';
		  var startPoint = $("#fiveOne_table").find("th").length+1;//搜索总计五险一金的起始行数
          var plength	= startPoint+1;// 每个总计五险一金的间距(加一因为起始点从零开始计算的)
          var fiveOneRow = (rowNum-1)*plength+startPoint;//当前需要搜索的行数
          /*alert(fiveOneRow);*/		  
		  var personFiveOne= $("#fiveOneResult_table tr:eq("+fiveOneRow+") td:eq(1)").text();
		  var orgFiveOne= $("#fiveOneResult_table tr:eq("+fiveOneRow+") td:eq(2)").text();
		  table_data+='<td>'+personFiveOne+'</td>';
		  table_data+='<td>'+orgFiveOne+'</td>';
		  var beforeTax = parseFloat(basicSalary)+parseFloat(bonus)-parseFloat(personFiveOne);//税前收入
		  table_data+='<td>'+beforeTax.toFixed(2)+'</td>';
		  var tax = findTax(beforeTax);
		  table_data+='<td>'+tax+'</td>';
		  var afterTax = parseFloat(beforeTax)-parseFloat(tax);
		  afterTax=afterTax.toFixed(2);
		  table_data+='<td>'+afterTax+'</td>'
		  table_data+='</tr>';
	   } 
			return table_data;
			
  }
 
});



